from .agent_chat_tab import AgentChatTab
from .stammdaten_assistant_tab import StammdatenAssistantTab
