from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTextEdit, QLineEdit, QPushButton, QHBoxLayout

class AgentChatTab(QWidget):
    def __init__(self, title_text, placeholder_text, controller, examples_text=None, parent=None):
        super().__init__(parent); self.controller=controller; self.setObjectName("card")
        layout = QVBoxLayout(self)
        title = QLabel(title_text); f=title.font(); f.setPointSize(f.pointSize()+3); f.setBold(True); title.setFont(f)
        layout.addWidget(title)
        if examples_text:
            helper = QLabel(examples_text); helper.setWordWrap(True); layout.addWidget(helper)
        self.transcript = QTextEdit(self); self.transcript.setReadOnly(True); layout.addWidget(self.transcript)
        row = QHBoxLayout(); self.input = QLineEdit(self); self.input.setPlaceholderText(placeholder_text)
        self.send = QPushButton("Senden"); self.send.setObjectName("add_btn"); self.send.clicked.connect(self._on_send)
        row.addWidget(self.input); row.addWidget(self.send); layout.addLayout(row)
        self.controller.response_ready.connect(self._append_agent)
        if examples_text: self._append_agent(examples_text)
    def _append_user(self, text): self.transcript.append("<b>Du:</b> {}".format(text))
    def _append_agent(self, text): self.transcript.append("<b>Assistent:</b> {}".format(text))
    def _on_send(self):
        t=self.input.text().strip()
        if not t: return
        self._append_user(t); self.input.clear(); self.controller.handle_message(t)
