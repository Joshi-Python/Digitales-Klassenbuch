from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTextEdit, QLineEdit, QPushButton, QHBoxLayout

class StammdatenAssistantTab(QWidget):
    def __init__(self, assistant, parent=None):
        super().__init__(parent)
        self.assistant = assistant
        self.setObjectName("card")

        layout = QVBoxLayout(self)

        title = QLabel("KI-Assistent (Stammdaten)")
        f = title.font(); f.setPointSize(f.pointSize()+3); f.setBold(True); title.setFont(f)
        layout.addWidget(title)

        helper = QLabel(
            "Tipp: Alles per Textbefehl.\n"
            "Beispiele:\n"
            "• „Importiere Schüler CSV“ / „Importiere Lehrer CSV“\n"
            "• „Lösche alle Schüler“ / „Lösche alle Lehrer“\n"
            "• „Füge Schüler Max Mustermann“ / „Lösche Lehrkraft Herr Weber“\n"
            "• „Setze Klasse 10b“ oder „Klasse: 10b“"
        )
        helper.setWordWrap(True)
        layout.addWidget(helper)

        self.transcript = QTextEdit(self); self.transcript.setReadOnly(True)
        layout.addWidget(self.transcript)

        row = QHBoxLayout()
        self.input = QLineEdit(self)
        self.input.setPlaceholderText("z. B. „Importiere Schüler CSV“, „Setze Klasse 10b“, …")
        self.send = QPushButton("Senden"); self.send.setObjectName("add_btn")
        row.addWidget(self.input); row.addWidget(self.send)
        layout.addLayout(row)

        self.send.clicked.connect(self._on_send)
        self.assistant.response_ready.connect(self._append_assistant)

        self._append_assistant("Bereit. Schreibe z. B. „Importiere Schüler CSV“ oder „Setze Klasse 10b“.")

    def _append_user(self, text: str): self.transcript.append("<b>Du:</b> " + text)
    def _append_assistant(self, text: str): self.transcript.append("<b>Assistent:</b> " + text)

    def _on_send(self):
        t = self.input.text().strip()
        if not t: return
        self._append_user(t); self.input.clear()
        self.assistant.handle_message(t)
