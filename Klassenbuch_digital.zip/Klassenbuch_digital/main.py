import sys, json
from pathlib import Path
from PyQt5.QtCore import Qt, QCoreApplication
from PyQt5.QtWidgets import QApplication, QMainWindow, QTabWidget, QFileDialog, QMessageBox

# Tabs
from tabs.stammdaten_tab import StammdatenTab
from tabs.stundenplan_tab import StundenplanTab
from tabs.anwesen_tab import AnwesenTab
from tabs.abwesen_tab import AbwesenTab
from tabs.noten_tab import NotenTab
from tabs.ausfall_tab import AusfallTab

# Models
from models.attendance_model import AttendanceModel
from models.grades_model import GradesModel
from models.cancellation_model import CancellationModel

# Assistants + UI
from assistants.attendance_assistant import AttendanceAssistant
from assistants.stammdaten_assistant import StammdatenAssistant
from assistants.cancellation_assistant import CancellationAssistant
from ui.agent_chat_tab import AgentChatTab
from ui.stammdaten_assistant_tab import StammdatenAssistantTab
from assistants.grades_assistant import GradesAssistant

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Klassenbuch – Multigrade Edition")
        self.filename="klassenbuch_data.json"; self._apply_stylesheet(); self._load_and_setup()

    def _load_data(self):
        try:
            p=Path(__file__).resolve().parent/self.filename
            with p.open("r", encoding="utf-8") as f: return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def save_data(self):
        grades_data=self.noten_tab.get_data_for_save()
        data = {
            "class_name": getattr(self.stammdaten_tab, "class_name", "Neue Klasse"),
            "pupils": self.stammdaten_tab.pupils,
            "teachers": self.stammdaten_tab.teachers,
            "attendance": self.anwesenheiten_tab.attendance_model.get_data_for_save(),
            "grades_by_subject": grades_data,
            "cancellations": self.cancellation_model.to_list(),
            "timetable": self.stundenplan_tab.get_data_for_save(),
        }
        try:
            p=Path(__file__).resolve().parent/self.filename
            with p.open("w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print(f"Fehler beim Speichern der Daten: {e}")

    def _reconcile_attendance_with_pupils(self):
        model = self.anwesenheiten_tab.attendance_model
        allowed = set(self.stammdaten_tab.pupils)
        filtered = [row for row in model.get_data_for_save() if row and row[0] in allowed]
        model.load_data(filtered)

    def closeEvent(self, event):
        self.save_data(); event.accept()

    def _load_and_setup(self):
        data=self._load_data()
        data_to_use = data if (data and data.get("pupils") is not None) else {
            "pupils": [], "teachers": [], "class_name": "Neue Klasse",
            "attendance": [], "grades_by_subject": {}, "cancellations": [],
            "timetable": {"days":["Mo","Di","Mi","Do","Fr"],"periods":["1","2","3","4","5","6"],"entries":[]}
        }

        self.pupils = data_to_use.get("pupils", [])
        self.teachers = data_to_use.get("teachers", [])
        self.class_name = data_to_use.get("class_name", "Neue Klasse")
        attendance_data = data_to_use.get("attendance", [])
        grades_by_subject_data = data_to_use.get("grades_by_subject", {})
        cancellations_data = data_to_use.get("cancellations", [])
        timetable_data = data_to_use.get("timetable", {"days":["Mo","Di","Mi","Do","Fr"],"periods":["1","2","3","4","5","6"],"entries":[]})

        self.stammdaten_tab = StammdatenTab(self.pupils, self.teachers, self.class_name, self)
        try:
            self.setWindowTitle(f"Klassenbuch – {self.class_name}")
        except Exception:
            pass

        self.anwesenheiten_tab = AnwesenTab(self.pupils, self); self.anwesenheiten_tab.attendance_model.load_data(attendance_data)
        self.noten_tab = NotenTab(self.pupils, grades_by_subject_data, self)
        self.abwesen_tab = AbwesenTab(self.anwesenheiten_tab.attendance_model, self)
        self.cancellation_model = CancellationModel(); self.cancellation_model.load_list(cancellations_data)
        self.ausfall_tab = AusfallTab(self.cancellation_model, self)
        self.stundenplan_tab = StundenplanTab(timetable_data, self)

        # KI-Assistenten
        self.attendance_ai = AttendanceAssistant(self)
        self.cancellation_ai = CancellationAssistant(self)
        self.stammdaten_ai = StammdatenAssistant(self)
        self.grades_ai = GradesAssistant(self)

        # Tabs
        tabs = QTabWidget()
        tabs.addTab(self.stammdaten_tab, "Stammdaten")
        tabs.addTab(self.stundenplan_tab, "Stundenplan")
        tabs.addTab(self.anwesenheiten_tab, "Anwesenheitsliste")
        tabs.addTab(self.abwesen_tab, "Abwesenheitsliste")
        tabs.addTab(self.noten_tab, "Notenliste")
        tabs.addTab(self.ausfall_tab, "Unterrichtsausfall")
        tabs.addTab(AgentChatTab
                    ("KI-Assistent (Anwesenheit)",
                                "Gebe den Namen von den Schüler:in ein",
                                 self.attendance_ai,
                                 examples_text="Beispiele (Anwesenheit):\n"
                                               "• „Max Mustermann“\n"
                                               "• Nur den Namen eingeben → wird abgehakt"

                    ),
                    "KI-Assistent (Anwesenheit)"
                    )
        tabs.addTab(AgentChatTab("KI-Assistent (Ausfall)",
                                 "Schreibe „Ausfall“, dann: Datum → Stunde → Fach → Grund.",
                    self.cancellation_ai,
                    examples_text=("Befehle (Unterrichtsausfall):\n"
                                   "• „Ausfall“ → Dialog (Datum → Stunde → Fach → Grund)\n"
                                   "• „Export“ → CSV exportieren und Liste leeren\n"
                                   "• „Liste leeren“ → Alle Ausfälle löschen\n"
                                   "• „Lösche Zeile 2“ / „Lösche Zeilen 2-4, 6“")),

                    "KI-Assistent (Ausfall)")
        tabs.addTab(StammdatenAssistantTab(self.stammdaten_ai, self), "KI-Assistent (Stammdaten)")
        tabs.addTab(AgentChatTab(
            "KI-Assistent (Noten)",
            "Schreibe Befehle wie:\n"
            "• „Mathe: Max Mustermann -> KA1 = 2“\n"
            "• „Max Mustermann -> Test 1 = 1.7“\n"
            "• „Fach: Mathe“ / „Wechsle Fach Mathe“ / „Fach löschen Mathe“\n"
            "• „Spalte hinzufügen Test 1“ / „Spalte löschen Test 2“",
            self.grades_ai,
            examples_text="Beispiele (Noten):\n"
                          "• „Mathe: Max Mustermann -> KA1 = 2“\n"
                          "• „Max Mustermann -> Test 1 = 1.7“\n"
                          "• „Fach: Mathe“, „Wechsle Fach Mathe“, „Fach löschen Mathe“\n"
                          "• „Spalte hinzufügen Test 1“, „Spalte löschen Test 2“"
        ), "KI-Assistent (Noten)")

        self.setCentralWidget(tabs)

        # Stammdaten ↔ Anwesenheit
        self.stammdaten_tab.pupil_added.connect(self.anwesenheiten_tab.attendance_model.add_pupil)
        self.stammdaten_tab.pupil_removed.connect(self.anwesenheiten_tab.attendance_model.remove_pupil)

        # Stammdaten ↔ Noten (stabile Slots)
        self.stammdaten_tab.pupil_added.connect(self.noten_tab.on_pupil_added)
        self.stammdaten_tab.pupil_removed.connect(self.noten_tab.on_pupil_removed)

        # Einmalig nach dem Laden: Noten-Modelle bereinigen/sortieren
        self.noten_tab.reconcile_with(self.stammdaten_tab.pupils)

        self._reconcile_attendance_with_pupils()

    def _reconcile_grades_with_pupils(self):
        allowed = set(self.stammdaten_tab.pupils)
        for model in self.noten_tab.all_grade_models.values():
            headers, rows = model.get_all_data()
            filtered = [row for row in rows if row and row[0] in allowed]
            model.beginResetModel()
            model._data = filtered
            model.endResetModel()

    def _on_pupil_removed(self, _name):
        if not self.stammdaten_tab.pupils:
            self.anwesenheiten_tab.attendance_model.load_data([])
            for model in self.noten_tab.all_grade_models.values():
                model.beginResetModel()
                model._data = []
                model.endResetModel()
            self.stammdaten_tab.pupil_removed.connect(self._on_pupil_removed)

    def _export_grades_to_file(self, model):
        headers, data = model.get_all_data()
        subject_name = self.noten_tab.subject_combo.currentText()
        file_path, _ = QFileDialog.getSaveFileName(self, "Noten exportieren",
                                                   f"Notenliste_{subject_name}.csv",
                                                   "CSV-Dateien (*.csv);;Text-Dateien (*.txt);;Alle Dateien (*)")
        if not file_path: return
        try:
            with open(file_path,'w',encoding='utf-8') as f:
                f.write(';'.join(headers)+'\n')
                for row in data: f.write(';'.join(map(str,row))+'\n')
            QMessageBox.information(self,"Export & Reset erfolgreich",
                                    f"Die Noten für **{subject_name}** wurden exportiert.\n\nDie Notenwerte wurden zurückgesetzt (Spalten bleiben).")
            model.clear_grades_data()
        except Exception as e:
            QMessageBox.critical(self,"Exportfehler",f"Fehler beim Speichern der Datei: {e}")

    def _apply_stylesheet(self):
        style_path = Path(__file__).resolve().parent / "style.css"
        if style_path.exists():
            try:
                with open(style_path,"r",encoding="utf-8") as f: self.setStyleSheet(f.read())
            except Exception as e:
                print(f"Fehler beim Laden des Stylesheets: {e}")

def main():
    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
    app = QApplication(sys.argv); win = MainWindow()
    win.resize(1280, 820); win.show(); sys.exit(app.exec_())

if __name__ == "__main__":
    main()

