import json
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QTableView, QHeaderView, QFileDialog, QMessageBox, QHBoxLayout
from PyQt5.QtGui import QStandardItemModel, QStandardItem
from PyQt5.QtCore import Qt

class StundenplanTab(QWidget):
    DAY_LABELS = ["Mo", "Di", "Mi", "Do", "Fr"]

    def __init__(self, timetable_data=None, parent=None):
        super().__init__(parent)
        self.setObjectName("card")

        data = timetable_data or {}
        self.days = data.get("days") or self.DAY_LABELS[:]

        if isinstance(data.get("periods"), list) and data["periods"]:
            self.periods = list(map(str, data["periods"]))
        elif "num_periods" in data:
            n = max(1, int(data["num_periods"]))
            self.periods = [str(i) for i in range(1, n+1)]
        else:
            self.periods = ["1", "2", "3", "4", "5", "6"]

        self.entries = data.get("entries", [])

        layout = QVBoxLayout(self)

        title = QLabel("Stundenplan")
        f = title.font(); f.setPointSize(f.pointSize()+2); f.setWeight(600)
        layout.addWidget(title)

        row_btns = QHBoxLayout()
        self.btn_import = QPushButton("Stundenplan aus JSON laden")
        self.btn_import.setObjectName("add_btn")
        self.btn_import.clicked.connect(self._import_json)

        self.btn_export = QPushButton("Stundenplan als JSON speichern")
        self.btn_export.setProperty("variant", "ghost")
        self.btn_export.clicked.connect(self._export_json)

        self.btn_clear = QPushButton("Stundenplan leeren")
        self.btn_clear.setObjectName("del_btn")
        self.btn_clear.clicked.connect(self._clear_timetable)

        row_btns.addWidget(self.btn_import)
        row_btns.addWidget(self.btn_export)
        row_btns.addWidget(self.btn_clear)
        layout.addLayout(row_btns)

        self.table = QTableView(self)
        self.table.setObjectName("timetable")
        self.model = QStandardItemModel(self)
        self.table.setModel(self.model)

        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableView.NoEditTriggers)
        self.table.setWordWrap(True)

        self.table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.verticalHeader().setDefaultSectionSize(34)

        header = self.table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(QHeaderView.Stretch)

        layout.addWidget(self.table)

        self._rebuild_model()
        self._fill_entries()

    def get_data_for_save(self):
        return {"days": self.days, "periods": self.periods, "entries": list(self.entries)}

    def load_data(self, data: dict):
        # 1) Daten setzen
        self.days = data.get("days") or self.DAY_LABELS[:]
        if isinstance(data.get("periods"), list) and data["periods"]:
            self.periods = list(map(str, data["periods"]))
        elif "num_periods" in data:
            n = max(1, int(data["num_periods"]))
            self.periods = [str(i) for i in range(1, n+1)]
        else:
            self.periods = ["1", "2", "3", "4", "5", "6"]

        self.entries = data.get("entries", [])

        # 2) Lehrkräfte synchronisieren (still)
        self._sync_teachers_from_entries(show_info=False)

        # 3) Einmal neu aufbauen & füllen
        self._rebuild_model()
        self._fill_entries()

    def set_entry(self, day_index: int, period_index: int, subject: str, teacher: str = "", room: str = ""):
        if not (0 <= day_index < len(self.days) and 0 <= period_index < len(self.periods)):
            return False
        self._remove_entry_internal(day_index, period_index)
        self.entries.append({
            "day": day_index, "period": period_index,
            "subject": subject or "", "teacher": teacher or "", "room": room or "",
        })
        self._paint_cell(day_index, period_index, subject, teacher, room)
        return True

    def remove_entry(self, day_index: int, period_index: int):
        if not (0 <= day_index < len(self.days) and 0 <= period_index < len(self.periods)):
            return False
        ok = self._remove_entry_internal(day_index, period_index)
        if ok:
            self.model.setItem(period_index, day_index, QStandardItem(""))
            self.table.resizeRowsToContents()
        return ok

    def clear_all(self):
        self.entries = []
        for r in range(len(self.periods)):
            for c in range(len(self.days)):
                self.model.setItem(r, c, QStandardItem(""))
        self.table.resizeRowsToContents()

    def day_to_index(self, text: str):
        t = (text or "").strip().lower()
        mapping = {"mo":0,"montag":0,"di":1,"dienstag":1,"mi":2,"mittwoch":2,"do":3,"donnerstag":3,"fr":4,"freitag":4}
        return mapping.get(t, None)

    def _rebuild_model(self):
        self.model.clear()
        self.model.setColumnCount(len(self.days))
        self.model.setRowCount(len(self.periods))
        self.model.setHorizontalHeaderLabels(self.days)
        self.model.setVerticalHeaderLabels(list(map(str, self.periods)))

    @staticmethod
    def _fmt(subject, teacher, room, multiline=False):
        if not subject and not teacher and not room:
            return ""
        if multiline:
            lines = []
            if subject: lines.append(subject)
            meta = " ".join(filter(None, [f"({teacher})" if teacher else "", f"| {room}" if room else ""])).strip()
            if meta: lines.append(meta)
            return "\n".join(lines) if lines else ""
        else:
            parts, tail = [], []
            if subject: parts.append(subject)
            if teacher: tail.append(f"({teacher})")
            if room:    tail.append(f"| {room}")
            if tail: parts.append(" ".join(tail))
            return " ".join(parts)

    def _fill_entries(self):
        for rec in self.entries:
            try:
                c = int(rec.get("day", 0)); r = int(rec.get("period", 0))
            except Exception:
                continue
            if 0 <= c < len(self.days) and 0 <= r < len(self.periods):
                self._paint_cell(c, r, rec.get("subject",""), rec.get("teacher",""), rec.get("room",""))

    def _sync_teachers_from_entries(self, show_info: bool = False):
        """
        Sammelt alle 'teacher' und 'subject' Felder aus self.entries und
        synchronisiert Lehrkräfte sowie deren Fächer mit den Stammdaten.

        """
        try:
            win = self.window()
            stammdaten = getattr(win, "stammdaten_tab", None)
            if stammdaten is None:
                return

            # Lehrernamen und Fächer sauber sammeln
            raw_pairs = [((e.get("teacher") or "").strip(), (e.get("subject") or "").strip())
                         for e in self.entries]
            pairs = [(t, s) for (t, s) in raw_pairs if t and s]

            # Zuerst Lehrkräfte-Liste ergänzen (nur Namen)
            teacher_names = sorted({t for (t, _) in pairs} | {(e.get("teacher") or "").strip() for e in self.entries if
                                                              (e.get("teacher") or "").strip()})
            if teacher_names:
                added_teachers = stammdaten.add_teachers_bulk(teacher_names)
            else:
                added_teachers = 0

            # Mapping Lehrer -> Fächer (dedupliziert)
            teacher_to_subjects = {}
            for t, s in pairs:
                teacher_to_subjects.setdefault(t, set()).add(s)

            # Fächer mergen (führt Lehrer ggf. auch an)
            merged_info = stammdaten.merge_teacher_subjects(teacher_to_subjects)  # (new_teachers, new_links)
            new_teachers_from_merge, new_links = merged_info if isinstance(merged_info, tuple) else (0, 0)

            if show_info and (added_teachers or new_teachers_from_merge or new_links):
                total_new_teachers = added_teachers + new_teachers_from_merge
                QMessageBox.information(
                    self, "Lehrkräfte/Fächer ergänzt",
                    f"{total_new_teachers} neue Lehrkraft/Lehrkräfte und {new_links} neue Fach-Zuordnung(en) übernommen."
                )
        except Exception as e:
            # bewusst leise – wir wollen das Laden nicht unterbrechen
            print("Teacher sync error:", e)

    def _paint_cell(self, day_idx, period_idx, subject, teacher, room):
        text = self._fmt(subject, teacher, room, multiline=True)
        item = QStandardItem(text)
        item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        item.setToolTip("\n".join([
            f"Fach: {subject or '—'}",
            f"Lehrkraft: {teacher or '—'}",
            f"Raum: {room or '—'}",
        ]))
        if subject:
            f = item.font(); f.setWeight(600); item.setFont(f)

        self.model.setItem(period_idx, day_idx, item)
        self.table.resizeRowsToContents()

    def _remove_entry_internal(self, day_idx, period_idx):
        before = len(self.entries)
        self.entries = [e for e in self.entries if not (e.get("day") == day_idx and e.get("period") == period_idx)]
        return len(self.entries) != before

    def _import_json(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Stundenplan laden", "", "JSON-Dateien (*.json);;Alle Dateien (*)"
        )
        if not file_path:
            return
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # 1) JSON in Struktur überführen
            days = data.get("days")
            self.days = list(map(str, days)) if isinstance(days, list) and days else self.DAY_LABELS[:]

            if isinstance(data.get("periods"), list) and data["periods"]:
                self.periods = list(map(str, data["periods"]))
            elif "num_periods" in data:
                n = max(1, int(data["num_periods"]))
                self.periods = [str(i) for i in range(1, n+1)]
            else:
                self.periods = ["1","2","3","4","5","6"]

            cleaned = []
            for e in data.get("entries", []):
                try:
                    col = int(e.get("day", 0))
                    row = int(e.get("period", 0))
                    subj = (e.get("subject") or e.get("subject_name") or "").strip()
                    tch  = (e.get("teacher") or "").strip()
                    room = (e.get("room") or "").strip()
                    if 0 <= col < len(self.days) and 0 <= row < len(self.periods):
                        cleaned.append({"day": col, "period": row, "subject": subj, "teacher": tch, "room": room})
                except Exception:
                    continue
            self.entries = cleaned

            # 2) Lehrer übernehmen (mit Hinweis)
            self._sync_teachers_from_entries(show_info=True)

            # 3) Einmal neu aufbauen & füllen
            self._rebuild_model()
            self._fill_entries()

            QMessageBox.information(
                self, "Import erfolgreich",
                f"Stundenplan geladen.\nTage: {len(self.days)} • Stunden pro Tag: {len(self.periods)}"
            )
        except Exception as e:
            QMessageBox.critical(self, "Importfehler", f"Die Datei konnte nicht geladen werden:\n{e}")

    def _export_json(self):
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Stundenplan speichern", "stundenplan.json",
            "JSON-Dateien (*.json);;Alle Dateien (*)"
        )
        if not file_path:
            return
        try:
            out = {"days": self.days, "periods": self.periods, "entries": self.entries}
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(out, f, ensure_ascii=False, indent=2)
            QMessageBox.information(self, "Export erfolgreich", f"Gespeichert nach:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Exportfehler", f"Speichern fehlgeschlagen:\n{e}")

    def _clear_timetable(self):
        reply = QMessageBox.question(
            self, "Bestätigung",
            "Stundenplan wirklich vollständig leeren?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return
        self.clear_all()
        self.entries = []
        QMessageBox.information(self, "Gelöscht", "Stundenplan wurde geleert.")

