from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QFormLayout, QLineEdit, QPushButton, QComboBox, QTableView, QHeaderView, QFileDialog, QMessageBox, QInputDialog
from PyQt5.QtCore import Qt
try:
    from models.grades_model import GradesModel
except ImportError:  # Paketstart (python -m Klassenbuch_digital.main) oder anderer Kontext
    from ..models.grades_model import GradesModel


class NotenlistenTab(QWidget):
    def __init__(self, grades_model, on_remove_subject=None, parent=None):
        super().__init__(parent)
        self.grades_model = grades_model
        self.on_remove_subject = on_remove_subject
        layout = QVBoxLayout(self)

        self.add_column_btn = QPushButton("Notenspalte hinzufügen")
        self.add_column_btn.setObjectName("add_btn")
        self.add_column_btn.clicked.connect(self._on_add_column)
        add_control_layout = QFormLayout()
        self.new_column_input = QLineEdit()
        self.new_column_input.setPlaceholderText("z.B. Klassenarbeit 1")
        add_control_layout.addRow("Spaltenname:", self.new_column_input)
        add_control_layout.addRow(self.add_column_btn)
        layout.addLayout(add_control_layout)

        self.delete_column_btn = QPushButton("Notenspalte löschen")
        self.delete_column_btn.setObjectName("del_btn")
        self.delete_column_btn.clicked.connect(self._on_delete_column)
        delete_control_layout = QFormLayout()
        self.delete_column_input = QLineEdit()
        self.delete_column_input.setPlaceholderText("Name der zu löschenden Spalte")
        delete_control_layout.addRow("Spaltenname Noten:", self.delete_column_input)
        delete_control_layout.addRow(self.delete_column_btn)
        layout.addLayout(delete_control_layout)

        self.export_btn = QPushButton("Noten als Textdatei exportieren und Liste zurücksetzen 💾")
        self.export_btn.clicked.connect(lambda: self.window()._export_grades_to_file(self.grades_model))
        layout.addWidget(self.export_btn)

        self.remove_subject_btn = QPushButton("Fach entfernen")
        self.remove_subject_btn.setObjectName("del_btn")
        if callable(self.on_remove_subject):
            self.remove_subject_btn.clicked.connect(self.on_remove_subject)
        else:
            self.remove_subject_btn.setEnabled(False)
        layout.addWidget(self.remove_subject_btn)

        self.grades_table = QTableView(self)
        self.grades_table.setModel(self.grades_model)
        self.grades_table.setAlternatingRowColors(True)
        self.grades_table.verticalHeader().setVisible(False)
        header = self.grades_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(QHeaderView.ResizeToContents)
        layout.addWidget(self.grades_table)

    def _on_add_column(self):
        name = self.new_column_input.text().strip()
        if not name: return
        self.grades_model.add_grade_column(name)
        self.grades_table.horizontalHeader().setSectionResizeMode(
            self.grades_model.columnCount()-1, QHeaderView.ResizeToContents
        )
        self.new_column_input.clear()

    def _on_delete_column(self):
        header_name = self.delete_column_input.text().strip()
        if not header_name:
            QMessageBox.warning(self, "Eingabe fehlt", "Bitte geben Sie den genauen Namen der Spalte ein."); return
        if header_name=="Name":
            QMessageBox.critical(self, "Fehler", "Die Spalte 'Name' kann nicht gelöscht werden."); return
        if self.grades_model.remove_grade_column(header_name):
            QMessageBox.information(self, "Erfolgreich", f"Notenspalte '{header_name}' wurde gelöscht.")
            self.delete_column_input.clear()
        else:
            QMessageBox.warning(self, "Nicht gefunden", f"Die Spalte '{header_name}' wurde nicht gefunden.")

class NotenTab(QWidget):
    def __init__(self, pupils, grade_models_data, parent=None):
        super().__init__(parent)
        self.pupils = pupils
        self.all_grade_models = {}
        self.current_tab_widget = None

        self.available_subjects = list(grade_models_data.keys()) if grade_models_data else ["Neues Fach"]
        for subject in self.available_subjects:
            m = GradesModel(pupils); m.load_data(grade_models_data.get(subject, {})); self.all_grade_models[subject]=m
        if not grade_models_data and "Neues Fach" not in self.all_grade_models:
            self.all_grade_models["Neues Fach"] = GradesModel(self.pupils); self.available_subjects=["Neues Fach"]

        layout = QVBoxLayout(self); self.setObjectName("card")
        title = QLabel("Notenliste"); f=title.font(); f.setPointSize(f.pointSize()+3); f.setBold(True); title.setFont(f)
        layout.addWidget(title)

        fach_layout = QFormLayout()
        self.subject_combo = QComboBox(self); self.subject_combo.addItems(self.available_subjects)
        self.subject_combo.currentIndexChanged.connect(self._change_subject)
        fach_layout.addRow("Aktuelles Fach:", self.subject_combo)

        self.add_subject_btn = QPushButton("Neues Fach anlegen")
        self.add_subject_btn.clicked.connect(self._add_new_subject)
        fach_layout.addWidget(self.add_subject_btn)

        layout.addLayout(fach_layout)

        self.content_container = QWidget(); self.content_layout = QVBoxLayout(self.content_container)
        self.content_layout.setContentsMargins(0,0,0,0); layout.addWidget(self.content_container)
        self._change_subject(0)

    def ensure_subject(self, subject_name, switch=True):
        subject_name = subject_name.strip()
        if subject_name not in self.all_grade_models:
            self.available_subjects.append(subject_name)
            self.all_grade_models[subject_name] = GradesModel(self.pupils)
            self.subject_combo.addItem(subject_name)
        if switch:
            self.subject_combo.setCurrentText(subject_name)
        return self.all_grade_models[subject_name]

    def current_subject(self): return self.subject_combo.currentText()

    def set_grade(self, subject, pupil_name, column_header, value):
        model = self.ensure_subject(subject, switch=False)
        headers, rows = model.get_all_data()
        if column_header not in headers:
            model.add_grade_column(column_header)
        col_index = model.header_labels.index(column_header)
        row_index = next((i for i, r in enumerate(rows) if r[0]==pupil_name), None)
        if row_index is None:
            model.add_pupil(pupil_name)
            headers, rows = model.get_all_data()
            row_index = next((i for i, r in enumerate(rows) if r[0]==pupil_name), None)
        idx = model.index(row_index, col_index)
        model.setData(idx, str(value), Qt.EditRole)
        model.dataChanged.emit(idx, idx, (Qt.DisplayRole, Qt.EditRole))

    def _change_subject(self, index):
        subject_name = self.subject_combo.currentText()
        if subject_name not in self.all_grade_models: return
        if self.current_tab_widget:
            self.current_tab_widget.setParent(None); self.content_layout.removeWidget(self.current_tab_widget)
        current_model = self.all_grade_models[subject_name]
        self.current_tab_widget = NotenlistenTab(current_model, on_remove_subject=self._remove_subject, parent=self.content_container)
        self.content_layout.addWidget(self.current_tab_widget)

    def _add_new_subject(self):
        new_subject, ok = QInputDialog.getText(self, "Neues Fach anlegen", "Name des neuen Fachs:")
        new_subject = (new_subject or "").strip()
        if not ok: return
        if not new_subject:
            QMessageBox.warning(self, "Hinweis", "Bitte einen Fachnamen eingeben."); return
        if new_subject in self.available_subjects:
            QMessageBox.warning(self, "Fehler", "Fach existiert bereits."); return
        self.available_subjects.append(new_subject)
        self.all_grade_models[new_subject] = GradesModel(self.pupils)
        self.subject_combo.addItem(new_subject)
        self.subject_combo.setCurrentText(new_subject)

    def _remove_subject(self):
        subject = self.subject_combo.currentText().strip()
        if not subject:
            QMessageBox.information(self, "Hinweis", "Kein Fach ausgewählt."); return

        if len(self.all_grade_models) == 1:
            if subject == "Neues Fach":
                QMessageBox.warning(self, "Nicht möglich",
                                    "Das letzte Standard-Fach „Neues Fach“ kann nicht entfernt werden.")
                return
            confirm = QMessageBox.question(
                self, "Letztes Fach",
                f"„{subject}“ ist das letzte Fach. Soll es entfernt und durch „Neues Fach“ ersetzt werden?",
                QMessageBox.Yes | QMessageBox.No
            )
            if confirm != QMessageBox.Yes: return
            self.all_grade_models.pop(subject, None)
            self.available_subjects = [s for s in self.available_subjects if s != subject]
            self.subject_combo.blockSignals(True)
            self.subject_combo.clear()
            self.all_grade_models["Neues Fach"] = GradesModel(self.pupils)
            self.available_subjects = ["Neues Fach"]
            self.subject_combo.addItem("Neues Fach")
            self.subject_combo.setCurrentText("Neues Fach")
            self.subject_combo.blockSignals(False)
            self._change_subject(0)
            return

        confirm = QMessageBox.question(
            self, "Fach löschen",
            f"Soll das Fach „{subject}“ wirklich entfernt werden?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm != QMessageBox.Yes: return

        next_subject = None
        for s in self.available_subjects:
            if s != subject:
                next_subject = s; break

        self.all_grade_models.pop(subject, None)
        self.available_subjects = [s for s in self.available_subjects if s != subject]

        self.subject_combo.blockSignals(True)
        self.subject_combo.clear()
        for s in self.available_subjects: self.subject_combo.addItem(s)
        if not self.available_subjects:
            self.available_subjects = ["Neues Fach"]
            self.all_grade_models["Neues Fach"] = GradesModel(self.pupils)
            self.subject_combo.addItem("Neues Fach")
            next_subject = "Neues Fach"
        self.subject_combo.setCurrentText(next_subject or self.available_subjects[0])
        self.subject_combo.blockSignals(False)
        self._change_subject(self.subject_combo.currentIndex())

    def get_data_for_save(self):
        save_data={}
        for subject, model in self.all_grade_models.items():
            headers, rows = model.get_all_data()
            if subject=="Neues Fach" and not rows and len(headers)<=1: continue
            save_data[subject]=model.get_data_for_save()
        if not save_data and "Neues Fach" in self.all_grade_models:
            save_data["Neues Fach"]=self.all_grade_models["Neues Fach"].get_data_for_save()
        return save_data

    def synchronize_pupil(self, name, action):
        curr = self.subject_combo.currentText()
        for model in self.all_grade_models.values():
            (model.add_pupil(name) if action=="added" else model.remove_pupil(name))
        if curr in self.all_grade_models:
            self.all_grade_models[curr].layoutChanged.emit()

    def on_pupil_added(self, name: str):
        for model in self.all_grade_models.values():
            model.add_pupil(name)

    def on_pupil_removed(self, name: str):
        for model in self.all_grade_models.values():
            model.remove_pupil(name)

    def reconcile_with(self, pupils: list):
        target = list(pupils)
        target_set = set(target)
        for model in self.all_grade_models.values():
            headers, rows = model.get_all_data()
            cols = model.grade_columns
            existing = {r[0]: r for r in rows if r and r[0] in target_set}

            new_rows = []
            for name in target:
                if name in existing:
                    new_rows.append(existing[name])
                else:
                    new_rows.append([name] + [""] * cols)

            model.beginResetModel()
            model._data = new_rows
            model.endResetModel()

