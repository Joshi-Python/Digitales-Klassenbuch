from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QFormLayout, QLineEdit, QPushButton, QListWidget, QMessageBox
from PyQt5.QtCore import pyqtSignal

class StammdatenTab(QWidget):
    pupil_added = pyqtSignal(str)
    pupil_removed = pyqtSignal(str)

    def __init__(self, pupils, teachers, class_name, parent=None):
        super().__init__(parent)
        self.pupils = pupils; self.teachers = teachers; self.class_name = class_name
        self.setObjectName("card")
        layout = QVBoxLayout(self)

        self.label = QLabel(f"Klasse: {self.class_name}")
        f=self.label.font(); f.setPointSize(f.pointSize()+4); f.setBold(True); self.label.setFont(f)
        layout.addWidget(self.label)

        # GUI zum Klassenname ändern
        self.class_edit = QLineEdit(self); self.class_edit.setPlaceholderText("Neuen Klassennamen eingeben …")
        class_btn = QPushButton("Klassenname übernehmen"); class_btn.clicked.connect(lambda: self.set_class_name(self.class_edit.text()))
        layout.addWidget(self.class_edit); layout.addWidget(class_btn)

        # Schüler-Form
        pupil_form = QFormLayout()
        self.pupil_name_input = QLineEdit(); self.pupil_name_input.setPlaceholderText("Name der Schülerin / des Schülers")
        self.add_pupil_btn = QPushButton("Schüler:in anlegen"); self.add_pupil_btn.setObjectName("add_btn")
        self.remove_pupil_btn = QPushButton("Ausgewählte:n Schüler:in entfernen"); self.remove_pupil_btn.setObjectName("del_btn")
        self.add_pupil_btn.clicked.connect(self._on_add_pupil)
        self.remove_pupil_btn.clicked.connect(self._on_remove_pupils)
        pupil_form.addRow("Schüler-Name:", self.pupil_name_input)
        pupil_form.addRow(self.add_pupil_btn); pupil_form.addRow(self.remove_pupil_btn)

        # Überschrift
        teacher_list_title = QLabel("Schüler und Lehrkräfte verwalten")
        ft=teacher_list_title.font(); ft.setBold(True); ft.setPointSize(ft.pointSize()+2); teacher_list_title.setFont(ft)
        layout.addWidget(teacher_list_title)

        # Lehrer-Form
        teacher_form = QFormLayout()
        self.teacher_name_input = QLineEdit(); self.teacher_name_input.setPlaceholderText("Name des/der Lehrers/Lehrerin (Fach)")
        self.add_teacher_btn = QPushButton("Lehrkraft anlegen"); self.add_teacher_btn.setObjectName("add_btn")
        self.remove_teacher_btn = QPushButton("Ausgewählte Lehrkraft entfernen"); self.remove_teacher_btn.setObjectName("del_btn")
        self.add_teacher_btn.clicked.connect(self._on_add_teacher)
        self.remove_teacher_btn.clicked.connect(self._on_remove_teacher)
        teacher_form.addRow("Lehrer-Name:", self.teacher_name_input)
        teacher_form.addRow(self.add_teacher_btn); teacher_form.addRow(self.remove_teacher_btn)

        layout.addLayout(pupil_form); layout.addLayout(teacher_form)

        # Schülerliste
        pupil_list_title = QLabel("Aktuelle Schülerliste")
        fp=pupil_list_title.font(); fp.setBold(True); fp.setPointSize(fp.pointSize()+2); pupil_list_title.setFont(fp)
        layout.addWidget(pupil_list_title)

        self.pupil_list_widget = QListWidget(); self.pupil_list_widget.setSelectionMode(QListWidget.SingleSelection)
        self.pupil_list_widget.addItems(self.pupils); layout.addWidget(self.pupil_list_widget)

        # Lehrerliste
        teacher_list_title = QLabel("Aktuelle Lehrkraftliste")
        fp = teacher_list_title.font(); fp.setBold(True); fp.setPointSize(fp.pointSize() + 2); teacher_list_title.setFont(fp)
        layout.addWidget(teacher_list_title)

        self.teacher_list_widget = QListWidget(); self.teacher_list_widget.setSelectionMode(QListWidget.SingleSelection)
        self.teacher_list_widget.addItems(self.teachers); layout.addWidget(self.teacher_list_widget)

    def _on_add_pupil(self):
        name = self.pupil_name_input.text().strip()
        if not name or name in self.pupils:
            QMessageBox.warning(self, "Eingabe ungültig", "Name fehlt oder existiert bereits."); return
        self.pupils.append(name); self.pupil_list_widget.addItem(name); self.pupil_added.emit(name); self.pupil_name_input.clear()

    def _on_remove_pupils(self):
        items = self.pupil_list_widget.selectedItems()
        if not items: QMessageBox.warning(self, "Auswahl fehlt", "Bitte wählen Sie eine/n Schüler:in aus."); return
        item = items[0]; name = item.text()
        reply = QMessageBox.question(self, 'Bestätigung', f"Sicher {name} entfernen?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            try: self.pupils.remove(name)
            except ValueError: pass
            self.pupil_list_widget.takeItem(self.pupil_list_widget.row(item))
            self.pupil_removed.emit(name)

    def _on_add_teacher(self):
        name = self.teacher_name_input.text().strip()
        if not name or name in self.teachers:
            QMessageBox.warning(self, "Eingabe ungültig", "Name fehlt oder existiert bereits."); return
        self.teachers.append(name); self.teacher_list_widget.addItem(name); self.teacher_name_input.clear()

    def _on_remove_teacher(self):
        items = self.teacher_list_widget.selectedItems()
        if not items: QMessageBox.warning(self, "Auswahl fehlt", "Bitte wählen Sie eine Lehrkraft aus."); return
        item = items[0]; name = item.text()
        reply = QMessageBox.question(self, 'Bestätigung', f"Sicher {name} entfernen?", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            try: self.teachers.remove(name)
            except ValueError: pass
            self.teacher_list_widget.takeItem(self.teacher_list_widget.row(item))
            QMessageBox.information(self, "Entfernt", f"Lehrkraft {name} wurde entfernt.")

    def set_class_name(self, new_name: str) -> bool:
        new_name = (new_name or "").strip()
        if not new_name:
            return False
        self.class_name = new_name
        self.label.setText(f"Klasse: {self.class_name}")
        try:
            self.window().setWindowTitle(f"Klassenbuch – {self.class_name}")
        except Exception:
            pass
        try:
            self.window().save_data()
        except Exception:
            pass
        return True

    def get_class_name(self) -> str:
        return self.class_name

    def clear_all_pupils(self) -> int:
        names = list(self.pupils)
        if not names: return 0
        self.pupils.clear()
        self.pupil_list_widget.clear()
        for n in names:
            self.pupil_removed.emit(n)
        return len(names)

    def clear_all_teachers(self) -> int:
        names = list(self.teachers)
        if not names: return 0
        self.teachers.clear()
        self.teacher_list_widget.clear()
        return len(names)

    def add_pupils_bulk(self, names: list):
        added = 0
        for n in names:
            n = (n or "").strip()
            if not n or n in self.pupils: continue
            self.pupils.append(n)
            self.pupil_list_widget.addItem(n)
            self.pupil_added.emit(n)
            added += 1
        return added

    def add_teachers_bulk(self, names: list):
        added = 0
        for n in names:
            n = (n or "").strip()
            if not n or n in self.teachers: continue
            self.teachers.append(n)
            self.teacher_list_widget.addItem(n)
            added += 1
        return added



