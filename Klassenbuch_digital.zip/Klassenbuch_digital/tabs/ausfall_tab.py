from datetime import datetime, timedelta
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QFormLayout, QLineEdit, QPushButton, QTableView, QHeaderView, QFileDialog, QMessageBox
from models.cancellation_model import CancellationModel





class AusfallTab(QWidget):
    def __init__(self, cancellations_model: CancellationModel, parent=None):
        super().__init__(parent)
        self.model = cancellations_model
        self.setObjectName("card")

        layout = QVBoxLayout(self)

        title = QLabel("Unterrichtsausfall")
        f = title.font()
        f.setPointSize(f.pointSize() + 3)
        f.setBold(True)
        title.setFont(f)
        layout.addWidget(title)

        form = QFormLayout()
        self.date_input = QLineEdit()
        self.date_input.setPlaceholderText("Datum (heute/morgen/DD.MM.YYYY/YYYY-MM-DD)")
        self.period_input = QLineEdit()
        self.period_input.setPlaceholderText("Stunde (z. B. 3)")
        self.subject_input = QLineEdit()
        self.subject_input.setPlaceholderText("Fach (z. B. Mathe)")
        self.reason_input = QLineEdit()
        self.reason_input.setPlaceholderText("Grund (optional)")

        add_btn = QPushButton("Ausfall hinzufügen")
        add_btn.setObjectName("add_btn")
        add_btn.clicked.connect(self._on_add)

        del_btn = QPushButton("Ausgewählte Einträge löschen")
        del_btn.setObjectName("del_btn")
        del_btn.clicked.connect(self._on_delete)

        exp_btn = QPushButton("Ausfälle als CSV exportieren 💾")
        exp_btn.clicked.connect(self._on_export)

        form.addRow("Datum:", self.date_input)
        form.addRow("Stunde:", self.period_input)
        form.addRow("Fach:", self.subject_input)
        form.addRow("Grund:", self.reason_input)
        form.addRow(add_btn)
        form.addRow(del_btn)
        form.addRow(exp_btn)
        layout.addLayout(form)

        self.table = QTableView(self)
        self.table.setModel(self.model)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QTableView.ExtendedSelection)

        header = self.table.horizontalHeader()
        for c in (0, 1, 2):
            header.setSectionResizeMode(c, QHeaderView.ResizeToContents)
        for c in (3, 4):
            header.setSectionResizeMode(c, QHeaderView.Stretch)

        layout.addWidget(self.table)
    @staticmethod
    def _parse_date(text):
        t = (text or "").strip().lower()
        if t == "heute":
            return datetime.now().date().isoformat()
        if t == "morgen":
            return (datetime.now().date() + timedelta(days=1)).isoformat()
        try:
            if "." in t:
                return datetime.strptime(t, "%d.%m.%Y").date().isoformat()
        except Exception:
            pass
        try:
            return datetime.strptime(t, "%Y-%m-%d").date().isoformat()
        except Exception:
            return None

    @staticmethod
    def _normalize_period(p):
        s = (str(p) or "").lower().replace("stunde", "").replace(".", "").strip()
        return int(s)

    def _on_add(self):
        d_txt = self.date_input.text().strip()
        p_txt = self.period_input.text().strip()
        subject = self.subject_input.text().strip()
        reason = self.reason_input.text().strip()

        date_iso = self._parse_date(d_txt)
        if not date_iso:
            QMessageBox.warning(self, "Ungültiges Datum", "heute/morgen/DD.MM.YYYY oder YYYY-MM-DD verwenden.")
            return
        try:
            period = self._normalize_period(p_txt)
        except Exception:
            QMessageBox.warning(self, "Ungültige Stunde", "Bitte ganze Zahl (z. B. 3).")
            return
        if not subject:
            QMessageBox.warning(self, "Fach fehlt", "Bitte ein Fach angeben.")
            return

        self.model.add_row(date_iso, period, subject, reason)
        self.date_input.clear()
        self.period_input.clear()
        self.subject_input.clear()
        self.reason_input.clear()

    def _on_delete(self):
        sel = self.table.selectionModel()
        rows = [i.row() for i in sel.selectedRows()] or sorted({ix.row() for ix in sel.selectedIndexes()})
        if not rows:
            QMessageBox.information(self, "Hinweis", "Bitte mindestens eine Zeile auswählen.")
            return
        self.model.remove_by_indices(rows)

    # ... existing code ...
    def _on_export(self):
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Ausfälle exportieren", "Unterrichtsausfall.csv",
            "CSV-Dateien (*.csv);;Alle Dateien (*)"
        )
        if not file_path:
            return
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write("Datum;Stunde;Fach;Grund\n")
                for r in self.model.to_list():
                    f.write(f"{r['date']};{r['period']};{r['subject']};{r['reason']}\n")
            # Nach erfolgreichem Export: Liste leeren
            rows = list(range(self.model.rowCount()))
            rows.sort(reverse=True)
            if rows:
                self.model.remove_by_indices(rows)
            QMessageBox.information(self, "Export erfolgreich", f"Export nach:\n{file_path}\n\nDie Liste wurde geleert.")
        except Exception as e:
            QMessageBox.critical(self, "Exportfehler", f"Fehler beim Speichern: {e}")

