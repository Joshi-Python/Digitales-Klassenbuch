from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QListWidget, QPushButton, QFileDialog, QMessageBox
from models.attendance_model import AttendanceModel

class AbwesenTab(QWidget):
    def __init__(self, attendance_model: AttendanceModel, parent=None):
        super().__init__(parent); self.attendance_model=attendance_model; self.setObjectName("card")
        layout = QVBoxLayout(self)
        title = QLabel("Abwesenheitsliste"); f=title.font(); f.setPointSize(f.pointSize()+3); f.setBold(True); title.setFont(f)
        layout.addWidget(title)

        self.absent_list = QListWidget(self); self.absent_list.setSelectionMode(QListWidget.NoSelection)
        layout.addWidget(self.absent_list)

        self.export_btn = QPushButton("Abwesenheitsliste exportieren 💾")
        self.export_btn.clicked.connect(self._export_absent_to_file)
        layout.addWidget(self.export_btn)

        self.attendance_model.dataChanged.connect(lambda *_: self.refresh_list())
        self.attendance_model.modelReset.connect(self.refresh_list)
        try:
            self.attendance_model.rowsInserted.connect(lambda *_: self.refresh_list())
            self.attendance_model.rowsRemoved.connect(lambda *_: self.refresh_list())
        except: pass
        self.refresh_list()

    def refresh_list(self):
        try: absent = self.attendance_model.get_attendance_data().get("abwesend", [])
        except: absent=[]
        self.absent_list.clear()
        self.absent_list.addItems(absent if absent else ["Niemand abwesend ✅"])

    def _export_absent_to_file(self):
        data = self.attendance_model.get_attendance_data()
        absent = data.get("abwesend", [])

        file_path, _ = QFileDialog.getSaveFileName(
            self, "Abwesenheitsliste exportieren", "Abwesenheit.txt",
            "Text-Dateien (*.txt);;Alle Dateien (*)"
        )
        if not file_path: return
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write("Abwesenheitsliste\n\n")
                if absent:
                    for name in absent:
                        f.write(f"- {name}\n")
                else:
                    f.write("Niemand abwesend\n")
            QMessageBox.information(self, "Export erfolgreich", f"Die Abwesenheitsliste wurde nach:\n{file_path}\ngespeichert.")
        except Exception as e:
            QMessageBox.critical(self, "Exportfehler", f"Fehler beim Speichern der Datei: {e}")
