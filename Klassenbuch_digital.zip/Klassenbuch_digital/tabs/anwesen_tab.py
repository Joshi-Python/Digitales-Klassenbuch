from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTableView, QPushButton, QFileDialog, QMessageBox, QHeaderView
from models.attendance_model import AttendanceModel

class AnwesenTab(QWidget):
    def __init__(self, pupils, parent=None):
        super().__init__(parent)
        self.pupils = pupils
        self.setObjectName("card")

        layout = QVBoxLayout(self)

        title = QLabel("Anwesenheitsliste")
        f = title.font(); f.setPointSize(f.pointSize()+3); f.setBold(True); title.setFont(f)
        layout.addWidget(title)

        self.attendance_table = QTableView(self)
        self.attendance_model = AttendanceModel(pupils)
        self.attendance_table.setModel(self.attendance_model)

        self.attendance_table.setAlternatingRowColors(True)
        self.attendance_table.verticalHeader().setVisible(False)

        header = self.attendance_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)

        layout.addWidget(self.attendance_table)

        self.read_data_btn = QPushButton("Anwesenheit als Textdatei exportieren und Liste zurücksetzen 💾")
        self.read_data_btn.clicked.connect(self._export_attendance_data)
        layout.addWidget(self.read_data_btn)

    def _export_attendance_data(self):
        data = self.attendance_model.get_attendance_data()
        present = data["anwesend"]; absent = data["abwesend"]

        output_text = (
            f"Anwesenheit erfasst ({len(present)} anwesend, {len(absent)} abwesend):\n\n"
            f"Anwesend:\n- " + ("\n- ".join(present) if present else "Niemand") + "\n\n"
            f"Abwesend:\n- " + ("\n- ".join(absent) if absent else "Niemand")
        )

        file_path, _ = QFileDialog.getSaveFileName(
            self, "Anwesenheitsliste exportieren", "Anwesenheit.txt",
            "Text-Dateien (*.txt);;Alle Dateien (*)"
        )
        if not file_path: return

        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(output_text)
            self.attendance_model.reset_attendance()
            QMessageBox.information(self, "Export & Reset erfolgreich",
                                    f"Die Anwesenheitsliste wurde nach:\n{file_path}\nexportiert und zurückgesetzt.")
        except Exception as e:
            QMessageBox.critical(self, "Exportfehler", f"Fehler beim Speichern der Datei: {e}")
