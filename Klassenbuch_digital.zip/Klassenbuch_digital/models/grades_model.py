from PyQt5.QtCore import QAbstractTableModel, Qt, QVariant, QModelIndex

class GradesModel(QAbstractTableModel):
    def __init__(self, pupils, parent=None):
        super().__init__(parent)
        self._data = [[name] for name in pupils]
        self.header_labels = ["Name"]
        self.grade_columns = 0

    def rowCount(self, parent=QModelIndex()): return len(self._data)
    def columnCount(self, parent=QModelIndex()): return 1 + self.grade_columns

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid(): return QVariant()
        val = self._data[index.row()][index.column()]
        return val if role in (Qt.DisplayRole, Qt.EditRole) else QVariant()

    def setData(self, index, value, role=Qt.EditRole):
        if index.isValid() and role==Qt.EditRole:
            self._data[index.row()][index.column()] = value
            self.dataChanged.emit(index, index, (Qt.DisplayRole, Qt.EditRole))
            return True
        return False

    def flags(self, index):
        if not index.isValid(): return Qt.NoItemFlags
        return Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role==Qt.DisplayRole and orientation==Qt.Horizontal and section<len(self.header_labels):
            return self.header_labels[section]
        return QVariant()

    def add_grade_column(self, header_name):
        self.beginInsertColumns(QModelIndex(), self.columnCount(), self.columnCount())
        self.header_labels.append(header_name)
        for row in self._data: row.append("")
        self.grade_columns += 1
        self.endInsertColumns()

    def remove_grade_column(self, header_name):
        try:
            col = self.header_labels.index(header_name)
            if col==0: return False
        except ValueError:
            return False
        self.beginRemoveColumns(QModelIndex(), col, col)
        self.header_labels.pop(col)
        for row in self._data: del row[col]
        self.grade_columns -= 1
        self.endRemoveColumns(); return True

    def add_pupil(self, name):
        if any(row[0]==name for row in self._data): return
        self.beginInsertRows(QModelIndex(), self.rowCount(), self.rowCount())
        self._data.append([name] + [""]*self.grade_columns)
        self.endInsertRows()

    def remove_pupil(self, name):
        for i, row in enumerate(self._data):
            if row[0]==name:
                self.beginRemoveRows(QModelIndex(), i, i)
                del self._data[i]; self.endRemoveRows(); return

    def get_all_data(self): return self.header_labels, self._data

    def load_data(self, data):
        self.beginResetModel()
        self._data = data.get("grades", [])
        self.header_labels = data.get("headers", ["Name"])
        self.grade_columns = len(self.header_labels)-1
        self.endResetModel()

    def get_data_for_save(self): return {"grades": self._data, "headers": self.header_labels}

    def clear_grades_data(self):
        self.beginResetModel()
        for row in self._data:
            for i in range(1, len(row)): row[i]=""
        self.endResetModel()
