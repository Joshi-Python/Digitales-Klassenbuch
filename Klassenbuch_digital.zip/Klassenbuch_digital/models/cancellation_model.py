from PyQt5.QtCore import QAbstractTableModel, Qt, QVariant, QModelIndex

class CancellationModel(QAbstractTableModel):
    HEADERS = ["#", "Datum", "Stunde", "Fach", "Grund"]
    def __init__(self, rows=None, parent=None):
        super().__init__(parent); self._rows = rows or []

    def rowCount(self, parent=QModelIndex()): return len(self._rows)
    def columnCount(self, parent=QModelIndex()): return len(self.HEADERS)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid(): return QVariant()
        r, c = index.row(), index.column()
        if role in (Qt.DisplayRole, Qt.EditRole):
            if c==0: return str(r+1)
            row = self._rows[r]
            return {1:row.get("date",""),2:str(row.get("period","")),3:row.get("subject",""),4:row.get("reason","")}[c]
        return QVariant()

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        return self.HEADERS[section] if role==Qt.DisplayRole and orientation==Qt.Horizontal else QVariant()

    def flags(self, index):
        if not index.isValid(): return Qt.NoItemFlags
        return Qt.ItemIsEnabled | Qt.ItemIsSelectable

    def add_row(self, date_iso, period, subject, reason):
        self.beginInsertRows(QModelIndex(), self.rowCount(), self.rowCount())
        self._rows.append({"date": date_iso, "period": int(period), "subject": subject, "reason": reason})
        self.endInsertRows()

    def remove_by_indices(self, rows_idx):
        for r in sorted(set(rows_idx), reverse=True):
            if 0<=r<len(self._rows):
                self.beginRemoveRows(QModelIndex(), r, r); del self._rows[r]; self.endRemoveRows()

    def remove_by_date(self, date_iso):
        self.beginResetModel()
        self._rows = [r for r in self._rows if r.get("date")!=date_iso]
        self.endResetModel()

    def to_list(self): return self._rows

    def load_list(self, rows):
        self.beginResetModel()
        clean=[]
        for it in (rows or []):
            try:
                clean.append({"date":str(it.get("date")), "period":int(it.get("period")),
                              "subject":str(it.get("subject","")), "reason":str(it.get("reason",""))})
            except: pass
        self._rows=clean; self.endResetModel()
