from PyQt5.QtCore import QAbstractTableModel, Qt, QVariant, QModelIndex

class AttendanceModel(QAbstractTableModel):
    def __init__(self, pupils, parent=None):
        super().__init__(parent)
        self._data = [[name, False] for name in pupils]
        self.header_labels = ["Name", "Anwesend"]

    def rowCount(self, parent=QModelIndex()): return len(self._data)
    def columnCount(self, parent=QModelIndex()): return len(self.header_labels)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid(): return QVariant()
        r, c = index.row(), index.column()
        value = self._data[r][c]
        if c == 0 and role == Qt.DisplayRole: return value
        if c == 1:
            if role == Qt.CheckStateRole: return Qt.Checked if value else Qt.Unchecked
            if role == Qt.DisplayRole: return QVariant()
        return QVariant()

    def setData(self, index, value, role=Qt.EditRole):
        if index.isValid() and role == Qt.CheckStateRole and index.column()==1:
            self._data[index.row()][1] = (value == Qt.Checked)
            self.dataChanged.emit(index, index, (Qt.CheckStateRole,))
            return True
        return False

    def flags(self, index):
        if not index.isValid(): return Qt.NoItemFlags
        return (Qt.ItemIsEnabled | Qt.ItemIsSelectable |
                (Qt.ItemIsUserCheckable if index.column()==1 else 0))

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        return self.header_labels[section] if role==Qt.DisplayRole and orientation==Qt.Horizontal else QVariant()

    def get_attendance_data(self):
        present = [n for n, p in self._data if p]
        absent  = [n for n, p in self._data if not p]
        return {"anwesend": present, "abwesend": absent}

    def add_pupil(self, name):
        if any(row[0]==name for row in self._data): return
        self.beginInsertRows(QModelIndex(), self.rowCount(), self.rowCount())
        self._data.append([name, False]); self.endInsertRows()

    def remove_pupil(self, name):
        for i, row in enumerate(self._data):
            if row[0]==name:
                self.beginRemoveRows(QModelIndex(), i, i)
                del self._data[i]; self.endRemoveRows(); return

    def get_data_for_save(self): return self._data

    def load_data(self, saved):
        if not isinstance(saved, list): return
        self.beginResetModel()
        cleaned=[]
        for row in saved:
            try: cleaned.append([str(row[0]), bool(row[1])])
            except: pass
        self._data=cleaned; self.endResetModel()

    def reset_attendance(self):
        self.beginResetModel()
        for row in self._data: row[1]=False
        self.endResetModel()

