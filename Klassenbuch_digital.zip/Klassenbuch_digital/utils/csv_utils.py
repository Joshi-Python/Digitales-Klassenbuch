

def read_names_from_csv(file_path: str):
    """
    Robustes Einlesen einer Namensliste (eine Spalte „Name“ oder erste Spalte).
    Unterstützt Trenner: ; , \t |   – ohne csv.Sniffer().
    Entfernt BOM (utf-8-sig), ignoriert leere Zeilen/Duplikate.
    """
    import csv, io
    try:
        with open(file_path, "r", encoding="utf-8-sig", newline="") as f:
            content = f.read()
    except Exception as e:
        raise ValueError(f"CSV konnte nicht gelesen werden: {e}")

    if not content.strip():
        return []

    delimiters = [";", ",", "\t", "|"]

    def collect_with_dictreader(delim: str):
        s = io.StringIO(content)
        reader = csv.DictReader(s, delimiter=delim)
        if not reader.fieldnames:
            return []
        name_field = None
        for fn in reader.fieldnames:
            if (fn or "").strip().lower() == "name":
                name_field = fn
                break
        if not name_field:
            return []
        out = []
        for row in reader:
            val = (row.get(name_field) or "").strip()
            if val:
                out.append(val)
        return out

    def collect_with_reader_first_col(delim: str):
        s = io.StringIO(content)
        reader = csv.reader(s, delimiter=delim)
        out = []
        for row in reader:
            if not row:
                continue
            val = (row[0] or "").strip()
            if not val:
                continue
            if val.lower() == "name":
                continue
            out.append(val)
        return out

    names = []
    for d in delimiters:
        names = collect_with_dictreader(d)
        if names:
            break
    if not names:
        for d in delimiters:
            names = collect_with_reader_first_col(d)
            if names:
                break
    if not names:
        out = []
        for ln in content.splitlines():
            val = (ln or "").strip()
            if val and val.lower() != "name":
                out.append(val)
        names = out

    seen, deduped = set(), []
    for n in names:
        if n and n not in seen:
            seen.add(n)
            deduped.append(n)
    return deduped

