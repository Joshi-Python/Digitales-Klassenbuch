import re
from datetime import datetime, timedelta
from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.QtWidgets import QFileDialog

class CancellationAssistant(QObject):
    response_ready = pyqtSignal(str)

    def __init__(self, win):
        super().__init__()
        self.win = win
        self.flow_active = False
        self.await_field = None
        self.flow_data = {}

    def _emit(self, msg):self.response_ready.emit(msg)

    def _help_text(self):
        return (
                "Befehle (Unterrichtsausfall):\n"
                "• „Ausfall“ → Dialog (Datum → Stunde → Fach → Grund)\n"
                "• „Export“ → CSV exportieren und Liste leeren\n"
                "• „Liste leeren“ → Alle Ausfälle löschen\n"
                "• „Lösche Zeile 2“ / „Lösche Zeilen 2-4, 6“"
        )

    @staticmethod
    def _parse_date(txt):
        t = (txt or "").strip().lower()
        if t == "heute":
            return datetime.now().date().isoformat()
        if t == "morgen":
            return (datetime.now().date() + timedelta(days=1)).isoformat()
        try:
            if "." in t:
                return datetime.strptime(t, "%d.%m.%Y").date().isoformat()
        except Exception:
            pass
        try:
            return datetime.strptime(t, "%Y-%m-%d").date().isoformat()
        except Exception:
            return None

    @staticmethod
    def _norm_period(p):
        return int((str(p) or "").lower().replace("stunde", "").replace(".", "").strip())

    def _ask_date(self):
        self.await_field = "date"
        self._emit("📅 Datum? (heute/morgen/DD.MM.YYYY/ YYYY-MM-DD) – oder „abbrechen“:")

    def _ask_period(self):
        self.await_field = "period"
        self._emit("⏰ Welche Stunde? (z. B. 3) – oder „abbrechen“:")

    def _ask_subject(self):
        self.await_field = "subject"
        self._emit("📘 Welches Fach? (z. B. Mathe) – oder „abbrechen“:")

    def _ask_reason(self):
        self.await_field = "reason"
        self._emit("📝 Grund (optional, Enter für leer) – oder „abbrechen“:")

    def _finish(self):
        d = self.flow_data
        self.win.cancellation_model.add_row(d["date_iso"], d["period"], d["subject"], d.get("reason", ""))
        self.flow_active = False
        self.await_field = None
        self.flow_data = {}
        return "✅ Ausfall eingetragen."

    def _start(self):
        self.flow_active = True
        self.flow_data = {}
        self._emit("Okay, wir tragen einen Unterrichtsausfall ein. (Du kannst jederzeit „abbrechen“ schreiben.)")
        self._ask_date()

    # --- NEU: Export/Leeren/Löschen-Features für den KI-Assistenten ---
    def _clear_all(self):
        rows = list(range(self.win.cancellation_model.rowCount()))
        rows.sort(reverse=True)
        if rows:
            self.win.cancellation_model.remove_by_indices(rows)
        return f"🗑️ Liste geleert. Entfernte Einträge: {len(rows)}"

    def _export_and_clear(self):
        file_path, _ = QFileDialog.getSaveFileName(self.win, "Ausfälle exportieren", "Unterrichtsausfall.csv",
                                                   "CSV-Dateien (*.csv);;Alle Dateien (*)")
        if not file_path:
            return "Abgebrochen – kein Speicherort gewählt."
        try:
            rows = self.win.cancellation_model.to_list()
            with open(file_path, "w", encoding="utf-8") as f:
                f.write("Datum;Stunde;Fach;Grund\n")
                for r in rows:
                    f.write(f"{r['date']};{r['period']};{r['subject']};{r['reason']}\n")
            clear_msg = self._clear_all()
            return f"💾 Export erfolgreich nach: {file_path}\n{clear_msg}"
        except Exception as e:
            return f"❌ Fehler beim Export: {e}"

    def _remove_rows_by_text(self, t: str):
        # Akzeptiert: "lösche zeile 2", "lösche zeilen 2-4, 6, 8-9"
        m = re.search(r'zeil(?:e|en)\s+(.+)$', t, re.IGNORECASE)
        if not m:
            return "⚠️ Bitte gib die Zeilen an, z. B. „lösche zeile 2“ oder „lösche zeilen 2-4, 6“."
        spec = m.group(1)
        parts = [p.strip() for p in re.split(r'[;,]', spec) if p.strip()]
        idxs = set()
        for p in parts:
            r = re.match(r'^(\d+)\s*-\s*(\d+)$', p)
            if r:
                a, b = int(r.group(1)), int(r.group(2))
                if a > b:
                    a, b = b, a
                for i in range(a, b + 1):
                    idxs.add(i)
            else:
                if re.match(r'^\d+$', p):
                    idxs.add(int(p))
        if not idxs:
            return "⚠️ Konnte keine gültigen Zeilen finden."
        # Nutzer zählt ab 1, Model ab 0
        zero_based = sorted({i - 1 for i in idxs if i > 0}, reverse=True)
        valid = [i for i in zero_based if 0 <= i < self.win.cancellation_model.rowCount()]
        if not valid:
            return "⚠️ Keine gültigen Zeilen im aktuellen Bereich."
        self.win.cancellation_model.remove_by_indices(valid)
        return f"🗑️ Gelöschte Zeilen (1-basiert): {', '.join(map(str, sorted(idxs)))}"
    # --- ENDE NEU ---

    def _flow(self, t):
        if re.match(r"(?i)^\s*abbrechen\s*$", t):
            self.flow_active = False
            self.await_field = None
            self.flow_data = {}
            self._emit("❎ Abgebrochen.")
            return
        if self.await_field == "date":
            iso = self._parse_date(t)
            if not iso:
                self._emit("⚠️ Datum nicht erkannt. Beispiel: heute | morgen | 30.10.2025 | 2025-10-30")
                self._ask_date()
                return
            self.flow_data["date_iso"] = iso
            self._ask_period()
            return
        if self.await_field == "period":
            try:
                p = self._norm_period(t)
            except Exception:
                self._emit("⚠️ Bitte ganze Zahl für die Stunde. Beispiel: 3")
                self._ask_period()
                return
            self.flow_data["period"] = p
            self._ask_subject()
            return
        if self.await_field == "subject":
            s = (t or "").strip()
            if not s:
                self._emit("⚠️ Bitte ein Fach angeben (z. B. Mathe).")
                self._ask_subject()
                return
            self.flow_data["subject"] = s
            self._ask_reason()
            return
        if self.await_field == "reason":
            self.flow_data["reason"] = (t or "").strip()
            self._emit(self._finish())
            return
        self._start()

    def handle_message(self, text):
        t = (text or "").strip()
        if self.flow_active:
            self._flow(t)
            return
        # NEU: zusätzliche Befehle
        if re.match(r"(?i)^\s*(export|exportieren|csv\s*export)\s*$", t):
            self._emit(self._export_and_clear())
            return
        if re.match(r"(?i)^\s*(liste\s*leeren|alles\s*l(?:ö|oe)schen)\s*$", t):
            self._emit(self._clear_all())
            return
        if re.match(r"(?i)^\s*lösche\s+zeil", t):
            self._emit(self._remove_rows_by_text(t))
            return
        # Bestehender Start des Ausfall-Dialogs
        if re.match(r"(?i)^\s*(ausfall|unterrichtsausfall)\s*$", t):
            self._start()
            return

        # Fallback → Hilfe
        self._emit(self._help_text())

