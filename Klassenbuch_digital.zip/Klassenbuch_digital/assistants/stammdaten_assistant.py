import re
from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.QtWidgets import QFileDialog
import sys
from pathlib import Path


try:
    # Bevorzugt: absoluter Import
    from utils.csv_utils import read_names_from_csv
except ImportError:
    # Fallback: Projekt-Root eine Ebene über "assistants" ergänzen
    ROOT = Path(__file__).resolve().parents[1]
    root_str = str(ROOT)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)
    from ..utils.csv_utils import read_names_from_csv



class StammdatenAssistant(QObject):
    response_ready = pyqtSignal(str)

    def __init__(self, win):
        super().__init__()
        self.win = win

    def _emit(self, msg: str):
        self.response_ready.emit(msg)

    def add_pupil(self, name: str):
        name = (name or "").strip()
        if not name: return "⚠️ Name fehlt."
        if name in self.win.stammdaten_tab.pupils:
            return f"ℹ️ '{name}' existiert bereits."
        self.win.stammdaten_tab.pupils.append(name)
        self.win.stammdaten_tab.pupil_list_widget.addItem(name)
        self.win.stammdaten_tab.pupil_added.emit(name)
        return f"✅ Schüler:in '{name}' angelegt."

    def remove_pupil(self, name: str):
        name = (name or "").strip()
        if not name: return "⚠️ Name fehlt."
        if name not in self.win.stammdaten_tab.pupils:
            return f"⚠️ '{name}' nicht gefunden."
        self.win.stammdaten_tab.pupils.remove(name)
        lw = self.win.stammdaten_tab.pupil_list_widget
        for i in range(lw.count()):
            if lw.item(i).text() == name:
                lw.takeItem(i); break
        self.win.stammdaten_tab.pupil_removed.emit(name)
        return f"🗑️ Schüler:in '{name}' entfernt."

    def add_teacher(self, name: str):
        name = (name or "").strip()
        if not name: return "⚠️ Name fehlt."
        if name in self.win.stammdaten_tab.teachers:
            return f"ℹ️ '{name}' existiert bereits."
        self.win.stammdaten_tab.teachers.append(name)
        self.win.stammdaten_tab.teacher_list_widget.addItem(name)
        return f"✅ Lehrkraft '{name}' angelegt."

    def remove_teacher(self, name: str):
        name = (name or "").strip()
        if not name: return "⚠️ Name fehlt."
        if name not in self.win.stammdaten_tab.teachers:
            return f"⚠️ '{name}' nicht gefunden."
        self.win.stammdaten_tab.teachers.remove(name)
        lw = self.win.stammdaten_tab.teacher_list_widget
        for i in range(lw.count()):
            if lw.item(i).text() == name:
                lw.takeItem(i); break
        return f"🗑️ Lehrkraft '{name}' entfernt."

    def set_class_name(self, name: str):
        ok = self.win.stammdaten_tab.set_class_name(name)
        return f"✅ Klasse gesetzt: „{self.win.stammdaten_tab.get_class_name()}“." if ok else "⚠️ Bitte einen gültigen Klassennamen angeben."

    def get_class_name(self):
        return f"Aktuelle Klasse: „{self.win.stammdaten_tab.get_class_name()}“."

    def import_csv(self, kind: str):
        title = "Schülerliste (CSV) wählen" if kind == "schueler" else "Lehrerliste (CSV) wählen"
        file_path, _ = QFileDialog.getOpenFileName(self.win, title, "", "CSV-Dateien (*.csv);;Alle Dateien (*)")
        if not file_path: return "Abgebrochen."
        try:
            names = read_names_from_csv(file_path)
            if not names: return "⚠️ Keine Namen in der CSV gefunden."
            if kind == "schueler":
                added = self.win.stammdaten_tab.add_pupils_bulk(names)
                return f"📥 {added} Schüler:in(nen) importiert."
            else:
                added = self.win.stammdaten_tab.add_teachers_bulk(names)
                return f"📥 {added} Lehrkraft/Lehrkräfte importiert."
        except Exception as e:
            return f"⚠️ Fehler beim Import: {e}"

    def clear_pupils(self):
        n = self.win.stammdaten_tab.clear_all_pupils()
        return f"🧹 Schülerliste geleert ({n} entfernt)." if n else "Schülerliste war bereits leer."

    def clear_teachers(self):
        n = self.win.stammdaten_tab.clear_all_teachers()
        return f"🧹 Lehrerliste geleert ({n} entfernt)." if n else "Lehrerliste war bereits leer."

    def handle_message(self, text: str):
        t = (text or "").strip()
        low = t.lower()

        if low in ("klasse?", "zeige klasse", "welche klasse", "aktuelle klasse"):
            self._emit(self.get_class_name()); return

        m = re.match(r"(?i)^\s*(?:setze|ändere)\s+klasse\s*:\s*(.+)$", t)
        if not m:
            m = re.match(r"(?i)^\s*(?:setze|ändere)\s+klasse\s+(.+)$", t)
        if not m:
            m = re.match(r"(?i)^\s*klasse\s*:\s*(.+)$", t) or re.match(r"(?i)^\s*klasse\s+(.+)$", t)
        if m:
            self._emit(self.set_class_name(m.group(1))); return

        if low in ("importiere schüler csv", "importiere schueler csv", "schüler csv", "schueler csv"):
            self._emit(self.import_csv("schueler")); return
        if low in ("importiere lehrkräfte csv", "importiere lehrer csv", "lehrkräfte csv", "lehrer csv"):
            self._emit(self.import_csv("lehrer")); return

        if re.match(r"(?i)^\s*(lösche|leere)\s+alle\s+schül", t):
            self._emit(self.clear_pupils()); return
        if re.match(r"(?i)^\s*(lösche|leere)\s+alle\s+lehr", t):
            self._emit(self.clear_teachers()); return

        m = re.match(r"(?i)^\s*(?:füge|addiere)\s+schül\w+\s+(.+)$", t)
        if m: self._emit(self.add_pupil(m.group(1))); return
        m = re.match(r"(?i)^\s*(?:lösche|entferne)\s+schül\w+\s+(.+)$", t)
        if m: self._emit(self.remove_pupil(m.group(1))); return
        m = re.match(r"(?i)^\s*(?:füge|addiere)\s+(?:lehrkraft|lehrer\w*)\s+(.+)$", t)
        if m: self._emit(self.add_teacher(m.group(1))); return
        m = re.match(r"(?i)^\s*(?:lösche|entferne)\s+(?:lehrkraft|lehrer\w*)\s+(.+)$", t)
        if m: self._emit(self.remove_teacher(m.group(1))); return

        self._emit(
            "Befehle (Stammdaten):\n"
            "• „Importiere Schüler CSV“ / „Importiere Lehrer CSV“\n"
            "• „Lösche alle Schüler“ / „Lösche alle Lehrer“\n"
            "• „Füge Schüler “ / „Füge Lehrer “\n"
            "•„Lösche Schüler “ / „Lösche Lehrer“ \n"
            "• „Setze Klasse “ oder „Klasse: “"
        )
