import re
from PyQt5.QtCore import QObject, pyqtSignal

class GradesAssistant(QObject):
    response_ready = pyqtSignal(str)

    def __init__(self, win):
        super().__init__()
        self.win = win  # Erwartet: win.noten_tab vorhanden

    def _emit(self, msg: str):
        self.response_ready.emit(msg)

    def _ensure_subject(self, subject: str, switch=True):
        return self.win.noten_tab.ensure_subject(subject, switch=switch)

    def _current_subject(self) -> str:
        return self.win.noten_tab.current_subject()

    def set_grade(self, subject: str, pupil: str, column: str, value: str):
        subject = (subject or "").strip() or self._current_subject()
        pupil = (pupil or "").strip()
        column = (column or "").strip()
        value = (value or "").strip()
        if not subject:
            return "⚠️ Bitte ein Fach angeben oder ein Fach auswählen."
        if not pupil or not column:
            return "⚠️ Bitte sowohl Schüler:in als auch Spaltennamen angeben."
        self.win.noten_tab.set_grade(subject, pupil, column, value)
        self._ensure_subject(subject, switch=True)
        return f"✅ Note gesetzt: {subject} | {pupil} | {column} = {value}"

    def add_subject(self, subject: str):
        s = (subject or "").strip()
        if not s:
            return "⚠️ Bitte einen Fachnamen angeben."
        self._ensure_subject(s, switch=True)
        return f"✅ Fach bereit: {s}"

    def switch_subject(self, subject: str):
        s = (subject or "").strip()
        if not s:
            return "⚠️ Bitte einen Fachnamen angeben."
        if s in self.win.noten_tab.all_grade_models:
            self._ensure_subject(s, switch=True)
            return f"🔁 Fach gewechselt: {s}"
        return f"⚠️ Fach nicht gefunden: {s}"

    def delete_subject(self, subject: str):
        s = (subject or "").strip()
        if not s:
            return "⚠️ Bitte einen Fachnamen angeben."
        if s not in self.win.noten_tab.all_grade_models:
            return f"⚠️ Fach nicht gefunden: {s}"
        # Fach auswählen und über vorhandene Logik entfernen
        self.win.noten_tab.subject_combo.setCurrentText(s)
        self.win.noten_tab._remove_subject()
        return f"🗑️ Fach entfernt: {s}"

    def add_column(self, column: str, subject: str = None):
        col = (column or "").strip()
        if not col:
            return "⚠️ Bitte Spaltennamen angeben."
        subj = (subject or "").strip() or self._current_subject()
        model = self._ensure_subject(subj, switch=True)
        model.add_grade_column(col)
        return f"🧩 Spalte hinzugefügt in {subj}: {col}"

    def delete_column(self, column: str, subject: str = None):
        col = (column or "").strip()
        if not col:
            return "⚠️ Bitte Spaltennamen angeben."
        subj = (subject or "").strip() or self._current_subject()
        if subj not in self.win.noten_tab.all_grade_models:
            return f"⚠️ Fach nicht gefunden: {subj}"
        model = self.win.noten_tab.all_grade_models[subj]
        ok = model.remove_grade_column(col)
        return f"🗑️ Spalte {'gelöscht' if ok else 'nicht gefunden'} in {subj}: {col}"

    def handle_message(self, text: str):
        t = (text or "").strip()
        if not t:
            self._emit("Bitte einen Befehl eingeben.")
            return

        # 1) Note setzen: optionales Fachpräfix
        m = re.match(r'^(?:(?P<subject>[^:]+?)\s*:\s*)?(?P<pupil>[^=\-:>]+?)\s*(?:->|:)\s*(?P<col>[^=]+?)\s*=\s*(?P<val>.+)$', t, re.IGNORECASE)
        if m:
            resp = self.set_grade(m.group('subject'), m.group('pupil'), m.group('col'), m.group('val'))
            self._emit(resp); return

        # 2) Fach anlegen: "Fach: <Name>" oder "Neues Fach <Name>"
        m = re.match(r'^(?:fach\s*:?\s*|neues\s+fach\s+)(?P<subject>.+)$', t, re.IGNORECASE)
        if m:
            self._emit(self.add_subject(m.group('subject'))); return

        # 3) Fach wechseln
        m = re.match(r'^(?:wechsle\s+fach|fach\s+wechseln)\s+(?P<subject>.+)$', t, re.IGNORECASE)
        if m:
            self._emit(self.switch_subject(m.group('subject'))); return

        # 4) Fach löschen
        m = re.match(r'^(?:fach\s+l(?:ö|oe)schen|fach\s+entfernen)\s+(?P<subject>.+)$', t, re.IGNORECASE)
        if m:
            self._emit(self.delete_subject(m.group('subject'))); return

        # 5) "<Fach>: Spalte hinzufügen <Name>" / "<Fach>: Spalte löschen <Name>"
        m = re.match(r'^(?P<subject>[^:]+?)\s*:\s*spalte\s+(?P<action>hinzuf(?:ü|ue)gen|add(?:ieren)?)\s+(?P<col>.+)$', t, re.IGNORECASE)
        if m:
            self._emit(self.add_column(m.group('col'), subject=m.group('subject'))); return
        m = re.match(r'^(?P<subject>[^:]+?)\s*:\s*spalte\s+l(?:ö|oe)schen\s+(?P<col>.+)$', t, re.IGNORECASE)
        if m:
            self._emit(self.delete_column(m.group('col'), subject=m.group('subject'))); return

        # 6) Spaltenbefehle ohne Fach (aktuelles Fach)
        m = re.match(r'^spalte\s+(?:hinzuf(?:ü|ue)gen|add(?:ieren)?)\s+(?P<col>.+)$', t, re.IGNORECASE)
        if m:
            self._emit(self.add_column(m.group('col'))); return
        m = re.match(r'^spalte\s+l(?:ö|oe)schen\s+(?P<col>.+)$', t, re.IGNORECASE)
        if m:
            self._emit(self.delete_column(m.group('col'))); return

        # Hilfe
        self._emit(
            "Befehle (Noten):\n"
            "• „Mathe: Max Mustermann -> KA1 = 2“\n"
            "• „Max Mustermann -> Test 1 = 1.7“ (aktuelles Fach)\n"
            "• „Fach: Mathe“, „Wechsle Fach Mathe“, „Fach löschen Mathe“\n"
            "• „Spalte hinzufügen Test 1“, „Spalte löschen Test 2“\n"
            "• „Mathe: Spalte hinzufügen KA1“, „Mathe: Spalte löschen KA1“"
        )