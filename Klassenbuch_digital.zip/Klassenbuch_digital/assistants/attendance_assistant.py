import re
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot, Qt, QRunnable, QThreadPool


class Worker(QRunnable):
    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn, self.args, self.kwargs = fn, args, kwargs
    def run(self):
        try:
            self.fn(*self.args, **self.kwargs)
        except Exception as e:
            print("Worker-Error:", e)


class AttendanceAssistant(QObject):
    response_ready = pyqtSignal(str)
    # NEU: Signal zum Ausführen im GUI-Thread
    do_in_main = pyqtSignal(object, tuple, dict)

    def __init__(self, win):
        super().__init__()
        self.win = win
        self.pool = QThreadPool.globalInstance()
        # Slot verbinden
        self.do_in_main.connect(self._ui_trampoline)

    # ---------- sichere UI-Updates ----------
    def _emit_safe(self, text: str):
        self.response_ready.emit(text)

    def _ui_call(self, fn, *args, **kwargs):
        # garantiert: Ausführung im GUI-Thread
        self.do_in_main.emit(fn, args, kwargs)

    @pyqtSlot(object, tuple, dict)
    def _ui_trampoline(self, fn, args, kwargs):
        try:
            msg = fn(*args, **kwargs)
            if msg:
                self._emit_safe(msg)
        except Exception as e:
            self._emit_safe(f"⚠️ Fehler: {e}")

    def _call_async(self, fn, *a, **kw):
        # nur für NICHT-UI-Arbeit
        def job():
            try:
                msg = fn(*a, **kw)
                if msg:
                    self._emit_safe(msg)
            except Exception as e:
                self._emit_safe(f"⚠️ Fehler: {e}")
        self.pool.start(Worker(job))

    # ---------- dein Sync-Marker + Abwesenheitsspiegel ----------
    def _set_attendance_checked(self, name: str, checked: bool):
        model = getattr(self.win.anwesenheiten_tab, "attendance_model", None)
        if not model or not hasattr(model, "_data"):
            return "⚠️ attendance_model fehlt."
        idx_row = next((i for i, r in enumerate(model._data) if str(r[0]) == name), None)
        actual = name
        if idx_row is None:
            m = {str(r[0]).strip().lower(): (i, r[0]) for i, r in enumerate(model._data)}
            k = (name or "").strip().lower()
            if k in m:
                idx_row, actual = m[k]
            else:
                return f"⚠️ '{name}' nicht gefunden."
        idx = model.index(idx_row, 1)
        state = Qt.Checked if checked else Qt.Unchecked
        model.setData(idx, state, Qt.CheckStateRole)
        return actual

    def _remove_from_absence(self, name: str):
        tab = self.win.anwesenheiten_tab
        lw = getattr(tab, "absence_list_widget", None)
        if lw:
            for it in lw.findItems(name, Qt.MatchExactly):
                lw.takeItem(lw.row(it))
            return
        am = getattr(tab, "absence_model", None)
        if am and hasattr(am, "_data"):
            rows = [i for i, r in enumerate(am._data)
                    if (r[0] if isinstance(r, (list, tuple)) else r) == name]
            for i in reversed(rows):
                del am._data[i]
            if hasattr(am, "layoutChanged"):
                am.layoutChanged.emit()

    def _add_to_absence(self, name: str):
        tab = self.win.anwesenheiten_tab
        lw = getattr(tab, "absence_list_widget", None)
        if lw:
            if not lw.findItems(name, Qt.MatchExactly):
                lw.addItem(name)
            return
        am = getattr(tab, "absence_model", None)
        if am and hasattr(am, "_data"):
            names = [(r[0] if isinstance(r, (list, tuple)) else r) for r in am._data]
            if name not in names:
                am._data.append((name,))
                if hasattr(am, "layoutChanged"):
                    am.layoutChanged.emit()

    def _mark_sync(self, name: str, status: str):
        present = (status == "present")
        actual = self._set_attendance_checked(name, present)
        if isinstance(actual, str) and actual.startswith("⚠️"):
            return actual
        if present:
            self._remove_from_absence(actual)
        else:
            self._add_to_absence(actual)
        return f"Anwesenheit für {actual}: {'anwesend' if present else 'abwesend'}."

    # ---------- Hilfe-Text ----------
    def _help_text(self):
        return (
            "Befehle (Anwesenheit):\n"
            "• „Max Mustermann“ → hakt anwesend ab (sofern gefunden)\n"
            "• „markiere <Name> anwesend/abwesend“"
        )

    # ---------- Public API ----------
    def handle_message(self, text):
        t = (text or "").strip()

        # Hilfe anzeigen
        if not t or re.match(r"(?i)^\s*(hilfe|help|\?)\s*$", t):
            return self._emit_safe(self._help_text())

        m = re.match(r"(?i)\s*(?:füge|addiere|neue?r?)\s+schül\w+\s+(.+)", t)
        if m:
            name = m.group(1).strip()
            return self._ui_call(self._add_pupil, name)

        m = re.match(r"(?i)\s*(?:markiere|setze)\s+(.+?)\s+(anwesend|abwesend)", t)
        if m:
            name = m.group(1).strip()
            status = "present" if m.group(2).lower().startswith("an") else "absent"
            return self._ui_call(self._mark_sync, name, status)

        if t:
            model = getattr(self.win.anwesenheiten_tab, "attendance_model", None)
            if model and hasattr(model, "_data"):
                mapping = {str(r[0]).strip().lower(): r[0] for r in model._data}
                k = t.strip().lower()
                if k in mapping:
                    return self._ui_call(self._mark_sync, mapping[k], "present")

        # Fallback: Hilfe
        return self._emit_safe(self._help_text())