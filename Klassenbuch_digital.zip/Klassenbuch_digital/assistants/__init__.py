# Der Package-Initializer bleibt absichtlich leer, um Side-Effect-Imports zu vermeiden.
# Imports der Assistant-Klassen erfolgen explizit dort, wo sie benötigt werden.

